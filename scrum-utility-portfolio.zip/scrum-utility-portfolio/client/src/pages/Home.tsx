import { useState } from "react";
import { Copy, ChevronDown, Code2, Zap, Target } from "lucide-react";
import hljs from "highlight.js";

interface Utility {
  id: string;
  title: string;
  version: string;
  developer: string;
  date: string;
  description: string;
  what: string;
  why: string;
  how: string;
  code: string;
}

const utilities: Utility[] = [
  {
    id: "colored-pivot",
    title: "Colored Pivot Table Automation",
    version: "SprintPlanWizard-ZeroSix",
    developer: "Sai V (PL6K130)",
    date: "09/24/2025",
    description: "Automates filtering of colored cells and creates dynamic PivotTables with real-time progress tracking.",
    what: "This utility scans Excel worksheets for rows with colored cells or specific conditions, filters them, and automatically generates a PivotTable with configured hierarchies.",
    why: "Manual filtering and pivot creation is time-consuming and error-prone. This automation ensures consistent, fast processing of sprint data while providing real-time progress feedback.",
    how: "The script iterates through worksheet rows, identifies colored cells, copies filtered data to a new sheet, and configures a PivotTable with Team and Key hierarchies.",
    code: `/**
 * This function automates the process of filtering rows with colored cells or specific conditions
 * from the active worksheet and creating a PivotTable based on the filtered data.
 */
function main(workbook: ExcelScript.Workbook) {
  const now = new Date();
  const options: Intl.DateTimeFormatOptions = {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
    timeZone: "Asia/Kolkata",
  };
  const formattedTime = now.toLocaleTimeString("en-US", options);
  
  let sheet = workbook.getActiveWorksheet();
  let usedRange = sheet.getUsedRange();
  if (!usedRange) return;

  let rowCount = usedRange.getRowCount();
  let colCount = usedRange.getColumnCount();

  // Prepare destination sheet
  let newSheetName = "ColoredPivotTab";
  let existing = workbook.getWorksheet(newSheetName);
  if (existing) {
    existing.delete();
  }
  let newSheet = workbook.addWorksheet(newSheetName);

  // Add loader in the first row
  let loaderCell = newSheet.getRange("A1");
  loaderCell.setValue("Processing: 0%");
  loaderCell.getFormat().getFont().setBold(true);
  loaderCell.getFormat().getFont().setColor("Blue");

  // Copy headers to the second row
  let headerRow = usedRange.getRow(0);
  newSheet.getRangeByIndexes(1, 0, 1, colCount).copyFrom(headerRow);

  // Identify the column with single-digit values
  let headers = headerRow.getValues()[0] as string[];
  let singleDigitColumnIndex = headers.findIndex(header => 
    header.toLowerCase().includes("story point")
  );

  // Track output row (start from the third row)
  let outRow = 2;

  // Scan each row (skip header row)
  for (let i = 1; i < rowCount; i++) {
    let rowRange = usedRange.getRow(i);
    let includeRow = false;

    for (let j = 0; j < colCount; j++) {
      let cell = rowRange.getCell(0, j);
      let fillColor = cell.getFormat().getFill().getColor();

      // Check for colored cells
      if (fillColor && fillColor !== "#FFFFFF" && fillColor.toLowerCase() !== "null") {
        includeRow = true;
        break;
      }
    }

    // Check if the single-digit column value is zero, null, or empty
    if (!includeRow && singleDigitColumnIndex !== -1) {
      let singleDigitValue = rowRange.getCell(0, singleDigitColumnIndex).getValue();
      if (singleDigitValue === 0 || singleDigitValue === null || singleDigitValue === "") {
        includeRow = true;
      }
    }

    if (includeRow) {
      newSheet.getRangeByIndexes(outRow, 0, 1, colCount).copyFrom(rowRange);
      outRow++;
    }

    // Update loader percentage
    let progress = Math.round((i / rowCount) * 100);
    loaderCell.setValue(\`Processing: \${progress}%\`);
  }

  // Define the copied range
  let coloredRange = newSheet.getRangeByIndexes(1, 0, outRow - 1, colCount);

  // Add Pivot Table on the new sheet
  let pivotDest = newSheet.getRangeByIndexes(1, colCount + 2, 1, 1);
  let pivot = workbook.addPivotTable("ColoredPivot", coloredRange, pivotDest);

  // Configure Row and Data fields
  if (headers.length > 0) {
    const teamHeaderIndex = headers.findIndex(header => 
      header.toLowerCase().includes("team")
    );
    if (teamHeaderIndex !== -1) {
      const teamHierarchy = pivot.getHierarchy(headers[teamHeaderIndex]);
      if (teamHierarchy) {
        pivot.addRowHierarchy(teamHierarchy);
      }
    }

    const keyHeaderIndex = headers.findIndex(header => 
      header.toLowerCase().includes("key")
    );
    if (keyHeaderIndex !== -1) {
      const keyHierarchy = pivot.getHierarchy(headers[keyHeaderIndex]);
      if (keyHierarchy) {
        pivot.addDataHierarchy(keyHierarchy, ExcelScript.AggregationFunction.count);
      }
    }
  }

  // Update loader to indicate completion
  loaderCell.setValue(\`SprintPlanWizard - 100% Processed - All Changes Detected at timestamp : \${formattedTime}\`);
  loaderCell.getFormat().getFont().setColor("Green");
  newSheet.setTabColor("#00FF00");

  // Add table at dynamically determined range
  let usedRange2 = newSheet.getUsedRange();
  let lastRow2 = usedRange.getRowCount();
  let lastCol2 = usedRange.getColumnCount();
  let tableRange2 = newSheet.getRangeByIndexes(1, 0, lastRow2 - 1, lastCol2);

  let newTable2 = workbook.addTable(tableRange2, true);
}`,
  },
];

export default function Home() {
  const [activeTab, setActiveTab] = useState<string>("colored-pivot");
  const [expandedSection, setExpandedSection] = useState<string | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);

  const currentUtility = utilities.find((u) => u.id === activeTab);

  const copyToClipboard = () => {
    if (currentUtility) {
      navigator.clipboard.writeText(currentUtility.code);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    }
  };

  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 animated-bg opacity-30 -z-10" />

      {/* Floating Particles */}
      <div className="fixed inset-0 overflow-hidden -z-10">
        <div className="absolute top-20 left-10 w-72 h-72 bg-cyan-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute top-1/2 left-1/2 w-80 h-80 bg-pink-500/5 rounded-full blur-3xl animate-pulse" />
      </div>

      {/* Header */}
      <header className="sticky top-0 z-50 glass-dark border-b border-cyan-500/20 backdrop-blur-xl">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-lg">
                <Code2 className="w-6 h-6 text-black" />
              </div>
              <div>
                <h1 className="text-2xl font-bold gradient-text">SprintVerse</h1>
                <p className="text-xs text-muted-foreground">Scrum Utility Portfolio</p>
              </div>
            </div>
            <nav className="hidden md:flex gap-6">
              <a href="#about-me" className="text-sm hover:text-cyan-400 transition-all duration-300 ease-out">
                About Me
              </a>
              <a href="#about-scrum" className="text-sm hover:text-cyan-400 transition-all duration-300 ease-out">
                About Scrum
              </a>
              <a href="#utilities" className="text-sm hover:text-cyan-400 transition-all duration-300 ease-out">
                Utilities
              </a>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 md:py-32 overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="inline-block px-4 py-2 glass-dark border border-cyan-500/30 rounded-full">
                <span className="text-sm text-cyan-400 font-semibold">✨ Automation Reimagined</span>
              </div>
              <h2 className="text-5xl md:text-6xl font-bold leading-tight">
                <span className="gradient-text">Automate Your</span>
                <br />
                <span className="text-white">Scrum Workflow</span>
              </h2>
              <p className="text-lg text-muted-foreground max-w-xl">
                Powerful Excel automation utilities designed to streamline sprint planning, data processing, and pivot table generation. Built for developers and scrum masters.
              </p>
              <div className="flex gap-4 pt-4">
                <button className="btn-neon">
                  Explore Utilities
                </button>
                <button className="btn-neon-outline">
                  Learn More
                </button>
              </div>
            </div>
            <div className="relative h-96 md:h-full">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663527887971/GChvpP5bv3Ko8mdtGHXyQW/automation-flow-NaJKRrZp4YwdQLbRP3bUe9.webp"
                alt="Automation Flow"
                className="w-full h-full object-cover rounded-xl shadow-2xl shadow-cyan-500/20"
              />
            </div>
          </div>
        </div>
      </section>

      {/* About Me Section */}
      <section id="about-me" className="py-20 border-t border-cyan-500/10">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-4xl font-bold mb-8 gradient-text">About Me</h2>
            <div className="glass p-8 space-y-4">
              <p className="text-lg leading-relaxed">
                I'm a passionate developer and automation enthusiast focused on creating efficient solutions for Scrum and project management workflows. With expertise in Excel scripting and data automation, I build tools that save teams hours of manual work.
              </p>
              <p className="text-lg leading-relaxed">
                My utilities are designed with developers and scrum masters in mind, providing powerful automation capabilities wrapped in an intuitive, easy-to-use interface. Every script is thoroughly tested and documented for maximum reliability.
              </p>
              <div className="pt-4 flex gap-4">
                <div className="flex-1 glass-dark p-4 rounded-lg border border-cyan-500/20">
                  <p className="text-cyan-400 font-semibold text-2xl">5+</p>
                  <p className="text-sm text-muted-foreground">Utilities Created</p>
                </div>
                <div className="flex-1 glass-dark p-4 rounded-lg border border-purple-500/20">
                  <p className="text-purple-400 font-semibold text-2xl">1000+</p>
                  <p className="text-sm text-muted-foreground">Hours Saved</p>
                </div>
                <div className="flex-1 glass-dark p-4 rounded-lg border border-pink-500/20">
                  <p className="text-pink-400 font-semibold text-2xl">100%</p>
                  <p className="text-sm text-muted-foreground">Reliability</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Scrum Section */}
      <section id="about-scrum" className="py-20 border-t border-cyan-500/10">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-4xl font-bold mb-8 gradient-text">About Scrum & Automation</h2>
            <div className="space-y-4">
              {[
                {
                  title: "What is Scrum?",
                  content:
                    "Scrum is an agile framework for managing product development. It emphasizes iterative progress, team collaboration, and continuous improvement through sprints, daily standups, and regular retrospectives.",
                },
                {
                  title: "Why Automation Matters",
                  content:
                    "Manual data processing in Scrum workflows is time-consuming and error-prone. Automation eliminates repetitive tasks, reduces human error, and allows teams to focus on what matters: delivering value.",
                },
                {
                  title: "Our Approach",
                  content:
                    "These utilities leverage Excel scripting to automate common Scrum tasks like filtering, pivoting, and reporting. They integrate seamlessly into your existing workflow without requiring external tools or complex setup.",
                },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="glass border border-cyan-500/20 overflow-hidden transition-all duration-300 ease-out"
                >
                  <button
                    onClick={() => toggleSection(item.title)}
                    className="w-full px-6 py-4 flex items-center justify-between hover:bg-white/5 transition-all duration-300 ease-out"
                  >
                    <h3 className="text-lg font-semibold text-left">{item.title}</h3>
                    <ChevronDown
                      className={`w-5 h-5 transition-transform ${
                        expandedSection === item.title ? "rotate-180" : ""
                      }`}
                    />
                  </button>
                  {expandedSection === item.title && (
                    <div className="px-6 py-4 border-t border-cyan-500/10 text-muted-foreground">
                      {item.content}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Utilities Section */}
      <section id="utilities" className="py-20 border-t border-cyan-500/10">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12 gradient-text">Code Utilities</h2>

          {/* Utility Tabs */}
          <div className="flex gap-3 mb-8 overflow-x-auto pb-4">
            {utilities.map((utility) => (
              <button
                key={utility.id}
                onClick={() => setActiveTab(utility.id)}
                className={`px-6 py-3 rounded-lg font-semibold transition-all duration-300 ease-out whitespace-nowrap ${
                  activeTab === utility.id
                    ? "bg-gradient-to-r from-cyan-500 to-purple-500 text-black shadow-lg shadow-cyan-500/50"
                    : "glass border border-cyan-500/20 hover:border-cyan-500/40"
                }`}
              >
                {utility.title}
              </button>
            ))}
          </div>

          {/* Utility Details */}
          {currentUtility && (
            <div className="space-y-6">
              {/* Header */}
              <div className="glass p-8 border border-cyan-500/20">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-3xl font-bold mb-2">{currentUtility.title}</h3>
                    <p className="text-muted-foreground">{currentUtility.description}</p>
                  </div>
                  <div className="text-right text-sm text-muted-foreground">
                    <p className="font-semibold text-cyan-400">{currentUtility.version}</p>
                    <p>by {currentUtility.developer}</p>
                    <p>{currentUtility.date}</p>
                  </div>
                </div>
              </div>

              {/* What, Why, How Cards */}
              <div className="grid md:grid-cols-3 gap-6">
                {[
                  { icon: Target, label: "What", content: currentUtility.what, color: "cyan" },
                  { icon: Zap, label: "Why", content: currentUtility.why, color: "purple" },
                  { icon: Code2, label: "How", content: currentUtility.how, color: "pink" },
                ].map((item, idx) => {
                  const Icon = item.icon;
                  const colorClass =
                    item.color === "cyan"
                      ? "border-cyan-500/20 glow-cyan"
                      : item.color === "purple"
                        ? "border-purple-500/20 glow-purple"
                        : "border-pink-500/20 glow-pink";

                  return (
                    <div key={idx} className={`glass p-6 border ${colorClass} transition-all duration-300 ease-out`}>
                      <div className="flex items-center gap-3 mb-4">
                        <Icon className="w-6 h-6 text-cyan-400" />
                        <h4 className="text-xl font-bold">{item.label}</h4>
                      </div>
                      <p className="text-muted-foreground leading-relaxed">{item.content}</p>
                    </div>
                  );
                })}
              </div>

              {/* Code Block */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-2xl font-bold">Source Code</h4>
                  <button
                    onClick={copyToClipboard}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300 ease-out ${
                      copiedCode
                        ? "bg-green-500/20 text-green-400 border border-green-500/30"
                        : "glass border border-cyan-500/20 hover:border-cyan-500/40"
                    }`}
                  >
                    <Copy className="w-4 h-4" />
                    {copiedCode ? "Copied!" : "Copy Code"}
                  </button>
                </div>
                <div className="code-block">
                  <pre>
                    <code
                      dangerouslySetInnerHTML={{
                        __html: hljs.highlight(currentUtility.code, {
                          language: "typescript",
                        }).value,
                      }}
                    />
                  </pre>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-cyan-500/10 py-12 mt-20">
        <div className="container mx-auto px-4">
          <div className="text-center text-muted-foreground">
            <p className="mb-2">© 2025 SprintVerse. All utilities are open for community use.</p>
            <p className="text-sm">Built with passion for developers and scrum teams.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
